{
  "items": [
    {
      "tags": [
        "java",
        "urlconnection"
      ],
      "owner": {
        "reputation": 1234,
        "user_id": 123456,
        "user_type": "registered",
        "accept_rate": 97,
        "profile_image": "https://www.gravatar.com/avatar/123456789abcdef?s=128&d=identicon&r=PG",
        "display_name": "asdf",
        "link": "http://stackoverflow.com/users/123456/asdf"
      },
      "is_answered": true,
      "view_count": 4153,
      "accepted_answer_id": 1234567,
      "answer_count": 2,
      "score": 1,
      "last_activity_date": 1339655703,
      "creation_date": 1278544994,
      "last_edit_date": 1278545557,
      "question_id": 1234555,
      "link": "http://stackoverflow.com/questions/1234555/java-urlconnection",
      "title": "Java URLConnection"
    },
    {
      "tags": [
        "java",
        "httpurlconnection"
      ],
      "owner": {
          "reputation": 5678,
          "user_id": 987654,
          "user_type": "registered",
          "accept_rate": 78,
          "profile_image": "https://www.gravatar.com/avatar/abcdef0123456789?s=128&d=identicon&r=PG",
          "display_name": "qwerty",
          "link": "http://stackoverflow.com/users/987654/qwerty"
        },
        "is_answered": true,
        "view_count": 45101,
        "answer_count": 6,
        "score": 47,
        "last_activity_date": 1453415991,
        "creation_date": 1260481126,
        "question_id": 123123,
        "link": "http://stackoverflow.com/questions/123123/urlconnection-doesnt-follow-redirect",
        "title": "URLConnection Doesn&#39;t Follow Redirect"
      }
  ],
  "has_more": true,
  "quota_max": 10000,
  "quota_remaining": 9985
}
      
