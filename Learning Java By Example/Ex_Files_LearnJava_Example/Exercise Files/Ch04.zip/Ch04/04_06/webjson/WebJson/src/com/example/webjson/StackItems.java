package com.example.webjson;

import java.util.List;

public class StackItems {
	private List<QueryResultBean> items;

	public List<QueryResultBean> getItems() {
		return items;
	}

	public void setItems(List<QueryResultBean> items) {
		this.items = items;
	}
	
}
