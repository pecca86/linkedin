package com.example.webjson.data;

import java.util.List;

public class ResultArray {
	private List<ResultData> items;

	public List<ResultData> getItems() {
		return items;
	}

	public void setItems(List<ResultData> items) {
		this.items = items;
	}
	
}
